/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "                                                                                                                                                                                                                                                                                                       
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "board.h"
#include "car_motor_control.h"
#include "line_sensor.h"
#include "test_logs.h"
#include "encoder.h"
#include "bsp_mpu6050.h"
#include "inv_mpu.h"


#ifndef printf
#define printf DEBUG_printf
#endif
#define left_deadzone 2
#define right_deadzone 2

// 声明全局变量，用于在中断和主程序间共享
static float offset = 0;   // 补偿角
static bool is_initialized = false;  // 初始化标志

/**
 * GPIOA中断处理函数
 * 用于处理yaw_error重置按钮的中断
 */
void GROUP1_IRQHandler(void)
{
    // 获取中断状态
    uint32_t interruptStatus = DL_GPIO_getRawInterruptStatus(GPIOA, DL_GPIO_PIN_2);
    
    // 检查是否是PA2引脚（yaw_error按钮）产生的中断
    if (interruptStatus & DL_GPIO_PIN_2) {
        // 重置初始化标志，这样下次获取姿态角时会重新保存初始偏航角
        is_initialized = false;
        
        printf("中断已触发\r\n");
        
        // 清除中断标志
        DL_GPIO_clearInterruptStatus(GPIOA, DL_GPIO_PIN_2);
    }
}

int main(void)
{

    // 初始化系统配置
    SYSCFG_DL_init();
	
	  //开启按键引脚的GPIOA端口中断
	  NVIC_EnableIRQ(mpu_6050_INT_IRQN );
    
    // 初始化延时函数
    Delay_init();
    
    // // 初始化电机控制模块
     Motor_init();
    
    // // 初始化巡线传感器
     LineSensor_init();
    
     // 初始化编码器模块
     Encoder_init();
	  
	
	  MPU6050_Init();
    
	  
    printf("Smart Car System Starting\r\n");
    
    // Wait for system to stabilize
    Delay_ms(1000);
		//Motor_straightLine(10,0.2);
    //mpu_6050_test();
		int16_t speed=10;
		float kp=0.8;
		
// 声明变量
    float pitch=0, roll=0, yaw=0;         // 欧拉角
    float yaw_error=0;                // 偏航角误差
    int16_t left_speed, right_speed;  // 左右轮速度
    int16_t speed_correction;       // 速度修正值
    bool forward = (speed >= 0);    // 判断前进还是后退
    int16_t abs_speed;              // 速度绝对值
    

// 		while(1){
// 		yaw+=1;
//     printf("yaw =%d\r\n", (int)yaw);
//     // 首次运行时保存初始偏航角作为参考
//     if (!is_initialized) {
//         offset = yaw;
//         is_initialized = true;
//         printf("offset =%d\r\n", (int)offset);
//     }
    
//     // 计算偏航角误差（当前偏航角与补偿角之差）
//     yaw_error = yaw-offset;
//     printf("yaw_error =%d\r\n", (int)yaw_error);
//     // 角度归一化到 -180 到 180 范围内
//     while (yaw_error > 180) yaw_error -= 360;
//     while (yaw_error < -180) yaw_error += 360;
    
//     // 使用比例控制计算速度修正值
//     // 当偏航角为正（向右偏）时，左轮速度减小，右轮速度增加
//     // 当偏航角为负（向左偏）时，左轮速度增加，右轮速度减小
//     speed_correction = (int16_t)(kp * yaw_error);
    
//     // 计算左右轮的速度
//     if (forward) {
//         // 前进时的修正
//         left_speed = abs_speed - speed_correction;
//         right_speed = abs_speed + speed_correction;
//     } else {
//         // 后退时的修正（注意后退时修正方向相反）
//         left_speed = -abs_speed - speed_correction;
//         right_speed = -abs_speed + speed_correction;
//     }
    
//     // 限制速度在有效范围内
//     if (forward) {
//         // 前进时的限制
//         if (left_speed < left_deadzone) left_speed = left_deadzone;
//         if (right_speed < right_deadzone) right_speed = right_deadzone;
//         if (left_speed > 90) left_speed = 90;
//         if (right_speed > 90) right_speed = 90;
//     } else {
//         // 后退时的限制
//         if (left_speed > -left_deadzone) left_speed = -left_deadzone;
//         if (right_speed > -right_deadzone) right_speed = -right_deadzone;
//         if (left_speed < -90) left_speed = -90;
//         if (right_speed < -90) right_speed = -90;
//     }
        
//         // 应用电机速度
//         //printf("left_speed: %d, right_speed: %d\r\n", left_speed, right_speed);
//         //Motor_setSpeed(left_speed, right_speed);
// 		    Delay_ms(500);

// }







	  //DMP初始化
      while( mpu_dmp_init() )
      {
            printf("dmp error\r\n");
            Delay_ms(200);
      }
    // 计算速度绝对值
    abs_speed = (speed < 0) ? -speed : speed;
    
    // 获取当前姿态角数据
		while(1){
    while(1){                                        //死循环
      //获取欧拉角
      if( mpu_dmp_get_data(&pitch,&roll,&yaw) == 0 )
            {
                  printf("\r\nyaw =%d\r\n", (int)yaw);
							    break;
            }

            Delay_ms(20);//根据设置的采样率，不可设置延时过大
      }
    // 首次运行时保存初始偏航角作为参考
    if (!is_initialized) {
        offset = yaw;
        is_initialized = true;
        printf("offset已设置\r\n");
    }
    
    // 计算偏航角误差（当前偏航角与初始偏航角之差）
    yaw_error = offset-yaw;
    printf("%f",yaw_error);
    // 角度归一化到 -180 到 180 范围内
    while (yaw_error > 180) yaw_error -= 360;
    while (yaw_error < -180) yaw_error += 360;
    
    // 使用比例控制计算速度修正值
    // 当偏航角为正（向右偏）时，左轮速度减小，右轮速度增加
    // 当偏航角为负（向左偏）时，左轮速度增加，右轮速度减小
    speed_correction = (int16_t)(kp * yaw_error);
    
    // 计算左右轮的速度
    if (forward) {
        // 前进时的修正
        left_speed = abs_speed - speed_correction;
        right_speed = abs_speed + speed_correction;
    } else {
        // 后退时的修正（注意后退时修正方向相反）
        left_speed = -abs_speed - speed_correction;
        right_speed = -abs_speed + speed_correction;
    }
    
    // 限制速度在有效范围内
    if (forward) {
        // 前进时的限制
        if (left_speed < left_deadzone) left_speed = left_deadzone;
        if (right_speed < right_deadzone) right_speed = right_deadzone;
        if (left_speed > 90) left_speed = 90;
        if (right_speed > 90) right_speed = 90;
    } else {
        // 后退时的限制
        if (left_speed > -left_deadzone) left_speed = -left_deadzone;
        if (right_speed > -right_deadzone) right_speed = -right_deadzone;
        if (left_speed < -90) left_speed = -90;
        if (right_speed < -90) right_speed = -90;
    }
        
        // 应用电机速度
        //printf("left_speed: %d, right_speed: %d\r\n", left_speed, right_speed);
        Motor_setSpeed(left_speed, right_speed);
		    Delay_ms(20);

}
		}

